package com.klef.jfsd.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.springboot.model.Admin;
import com.klef.jfsd.springboot.model.Faculty;
import com.klef.jfsd.springboot.model.Student;
import com.klef.jfsd.springboot.service.FacultyService;
import com.klef.jfsd.springboot.service.StudentService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class FacultyController 
{
	@Autowired
 private FacultyService facultyService;
	
	@Autowired
	private StudentService studentService;
	

	@GetMapping("facultylogin")
	public ModelAndView facultylogin()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("facultylogin");
		return mv;
	}
	
	@PostMapping("CheckFacultyLogin")
	public ModelAndView CheckFacultyLogin(HttpServletRequest request)
	{
		ModelAndView mv = new ModelAndView();
		
		String cemail = request.getParameter("cemail");
		String cpwd = request.getParameter("cpwd");
		
	   Faculty faculty = facultyService.CheckFacultyLogin(cemail, cpwd);
	   if(faculty != null)
	   {
		mv.setViewName("facultyhome");
	   }
	   else
	   {
		mv.setViewName("facultyloginfail");
		mv.addObject("msg", "login Failed");
	   }
	  return mv;
	}
	
	@GetMapping("facultyhome")
	public ModelAndView facultyhome()
	{
		ModelAndView mv =  new ModelAndView();
		mv.setViewName("facultyhome");
		return mv;
	}
	
	@GetMapping("displaystudentsbyfac")
	public ModelAndView displaystudentsbyfac()
	{
		ModelAndView mv = new ModelAndView();
		List<Student> stdlist = facultyService.viewAllStudentsbyfac();
		mv.setViewName("displaystudentsbyfac");
		mv.addObject("stdlist", stdlist);
		
		long count = facultyService.stdcount();
		mv.addObject("count", count);
		return mv;
		
	}
	
	
	
}
