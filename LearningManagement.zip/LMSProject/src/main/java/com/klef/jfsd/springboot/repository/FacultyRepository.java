package com.klef.jfsd.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.klef.jfsd.springboot.model.Faculty;

public interface FacultyRepository extends JpaRepository<Faculty,Integer>
{
  
	@Query("select f from Faculty f WHERE f.email=?1 and f.password=?2 ")
	public Faculty CheckFacultyLogin(String email,String password);
}
