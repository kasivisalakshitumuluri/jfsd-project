package com.klef.jfsd.springboot.service;

import java.util.List;

import com.klef.jfsd.springboot.model.Student;

public interface StudentService 
{
	
 public Student CheckStudentLogin(String email,String password);
 public String StudentReg(Student s);
 public String updateStudent(Student s);
public Student displayStudentById(int id);


 
}
