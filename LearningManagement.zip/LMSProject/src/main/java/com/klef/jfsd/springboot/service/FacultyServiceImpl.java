package com.klef.jfsd.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.springboot.model.Faculty;
import com.klef.jfsd.springboot.model.Student;
import com.klef.jfsd.springboot.repository.FacultyRepository;
import com.klef.jfsd.springboot.repository.StudentRepository;

@Service
public class FacultyServiceImpl  implements FacultyService
{
	
	@Autowired
	private FacultyRepository facultyRepository;
	
	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> viewAllStudentsbyfac() {
		
		return studentRepository.findAll();
	}

	@Override
	public Faculty CheckFacultyLogin(String email,String password) {
		
		return facultyRepository.CheckFacultyLogin(email, password);
	}

	@Override
	public void addtask() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String FacReg(Faculty f)
	{
		facultyRepository.save(f);
		return "Faculty Registered Successfully";
	}

	@Override
	public long stdcount() {
		
		return studentRepository.count();
	}

	
	
	

}
